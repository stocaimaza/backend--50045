export class CreateUserDto {
    id: Number;
    first_name: string;
    last_name:string;
    password:string;
    email:string;
    avatar:string;
}
