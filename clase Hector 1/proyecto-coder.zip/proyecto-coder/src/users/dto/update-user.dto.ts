import { PartialType } from '@nestjs/mapped-types';
import { CreateUserDto } from './create-user.dto';

export class UpdateUserDto extends PartialType(CreateUserDto) {
    id: Number;
    first_name: string;
    last_name:string;
    password:string;
    email:string;
    avatar:string;
}
