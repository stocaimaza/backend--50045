import { Injectable } from '@nestjs/common';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { User } from './entities/user.entity';

@Injectable()
export class UsersService {
  users: Array<User>

  constructor(){
    // this.users = [];
    this.users = [
      new User(1, 'John', 'Doe', 'john.doe@example.com', 'password123', 'https://example.com/avatars/johndoe.jpg'),
      new User(2, 'Jane', 'Smith', 'jane.smith@example.com', 'password123', 'https://example.com/avatars/janesmith.jpg'),
      new User(3, 'Alice', 'Johnson', 'alice.johnson@example.com', 'password123', 'https://example.com/avatars/alicejohnson.jpg'),
      new User(4, 'Bob', 'Brown', 'bob.brown@example.com', 'password123', 'https://example.com/avatars/bobbrown.jpg'),
      new User(5, 'Charlie', 'Davis', 'charlie.davis@example.com', 'password123', 'https://example.com/avatars/charliedavis.jpg'),
      new User(6, 'David', 'Wilson', 'david.wilson@example.com', 'password123', 'https://example.com/avatars/davidwilson.jpg'),
      new User(7, 'Eva', 'Martinez', 'eva.martinez@example.com', 'password123', 'https://example.com/avatars/evamartinez.jpg'),
      new User(8, 'Frank', 'Miller', 'frank.miller@example.com', 'password123', 'https://example.com/avatars/frankmiller.jpg'),
      new User(9, 'Grace', 'Lee', 'grace.lee@example.com', 'password123', 'https://example.com/avatars/gracelee.jpg'),
      new User(10, 'Hannah', 'Clark', 'hannah.clark@example.com', 'password123', 'https://example.com/avatars/hannahclark.jpg')
    ]
  }

  create(createUserDto: CreateUserDto) {
    const id = this.users.length + 1;
    const newUser = new User(
      id,
      createUserDto.first_name,
      createUserDto.last_name || '',
      createUserDto.email,
      createUserDto.password,
      createUserDto.avatar || '',
    );
    this.users.push(newUser);
    return newUser;
  }

  findAll(limit: number) {
    return limit ? this.users.slice(0, limit) : this.users;
  }

  findOne(id: number) {
    return this.users.find(user => user.id === id);
  }

  update(id: number, updateUserDto: UpdateUserDto) {
    const userIndex = this.users.findIndex( user => user.id === id);
    if( userIndex === -1){
      return undefined
    }
    const user = this.users[userIndex];
    this.users[userIndex] = {
      ...user,
      ...updateUserDto,
    }
    const userUpdate = this.users.find(user => user.id === id);
    return userUpdate;
  }

  remove(id: number) {
    const userIndex = this.users.findIndex( user => user.id === id);
    if( userIndex === -1){
      return undefined
    }
    this.users.splice(userIndex, 1)[0];
    return null;
  }
}
